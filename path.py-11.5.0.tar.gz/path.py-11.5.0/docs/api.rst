===
API
===

.. important::
    The documented methods' signatures are not always correct.
    See :class:`path.Path`.

.. automodule:: path
   :members:
   :undoc-members:
